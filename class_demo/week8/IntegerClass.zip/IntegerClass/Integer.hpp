// Integer Header

class Integer {
    int number;
    public:
    Integer();
    Integer(int);
    int getNumber();
    void setNumber(int);
};
