#include "list.hpp"

//put the implementation of your assigned functions here
