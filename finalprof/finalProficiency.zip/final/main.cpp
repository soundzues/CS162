#include "list.hpp"
using namespace std;

int main()
{
    node * head = NULL;
    build(head); // After this call, 10 to 20 nodes, starting at head.
    display(head);

    //PLEASE PUT YOUR CODE HERE to call the functions assigned.

    display(head);
    destroy(head);
    
    return 0;
}
