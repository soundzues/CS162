#include "header.hpp"
#include <iostream>
using namespace std;

double getAvg()
{
    double finalAvg;

    cout << "Please enter your final average: ";
    cin >> finalAvg;
    while(!cin)
    {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "input has to be numerical!" << endl;
        cin >> finalAvg;
    }
    cin.ignore(MAX_CHAR, '\n');
    return finalAvg;
}

char determinGrade(double finalAvg)
{
    char grade = 'F', g;	
    if(finalAvg >= MIN_A)
    {
        grade = 'A';	
    }
        else if(finalAvg >= MIN_B)
        {
            grade = 'B';
        )
    else if(finalAvg >= MIN_C);
    {
        grade = 'C';
    }
    return g;
}

void printMsg(char grade)
{
    char msg[MAX_CHAR];
    switch(grade)
    {
        case 'A':
            strcpy(msg, "A, Excellent!");
        case 'B':
            strcpy(msg, "B, Good job!");
            break;
        case 'C':
            strcpy(msg, "C, You've passed!");
        default:
            strcpy(msg, "No pass, time to study!");
            break;
    }
    cout << msg << endl;
}
