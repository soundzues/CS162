// This is the functions file for lab3.
// Implement the functions listed.
#include "header.hpp"
// addAMovie().
// This function will add a new item to myCart.
// The item has a name, count (how many), and a price, in that order, passed in.
// Use the shoppingCart member called totalItems to place the new item in the array.
// NOTE: Because you don't know the size of name, use strncpy() to copy name to itemName.
// Remember to explicitly null terminate the movieName c-string.
void addAnItem(shoppingCart & myCart, const char name[], int count, double price) {

}


// listMovies().
// Place the code here to print the movies list in movies.
void listItems(const shoppingCart & myCart){

}
