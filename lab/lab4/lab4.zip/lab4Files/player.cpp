// Implementation file for lab
#include "player.hpp"

void PlayerType::print() const {
    cout << "Player Name: " << name << ", Player Team: " << team << ", Batting Average: " << avg << ", Year: " << year << endl;
}

// Place your member function definitions here:
// 1: The constructor.
// 2: Function definition for higherAvg.
// 3: Function definition for moreTime.
