// CS162 Midterm Proficiency
// array.cpp, function definition / implementation file. 

#include "array.hpp"

//put the assigned function definitions here


// *** End of array.cpp ***
