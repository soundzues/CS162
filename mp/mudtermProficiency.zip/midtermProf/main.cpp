// Main function for CS162 midterm proficiency.
#include "array.hpp"

using namespace std;

int main()
{
    int list[CAP];
    int size = 15;
    build(list, size); // build() places random numbers in list.

    display(list, size); // display() will send the entire array to the screen.

    //PLEASE PUT YOUR CODE HERE to call the functions assigned

    display(list, size); // This second call to display() will verify your code.
    
    return 0;
}
// *** End of main.cpp ***
