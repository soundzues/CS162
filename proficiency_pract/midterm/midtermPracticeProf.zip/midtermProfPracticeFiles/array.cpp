//array.cpp 

#include "array.h"

//put the implementations of your assigned functions here
int numOfEven(int list[], int size) {

}

bool insert(int list[], int & size, int newInt, int pos) {

}

// *** End of array.cpp ***
